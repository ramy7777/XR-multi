'use client'

import { useEffect, useRef, useState } from 'react'

export function useWebSocket(url: string) {
  const [lastMessage, setLastMessage] = useState<string | null>(null)
  const wsRef = useRef<WebSocket | null>(null)

  useEffect(() => {
    wsRef.current = new WebSocket(url)

    wsRef.current.onmessage = (event) => {
      setLastMessage(event.data)
    }

    return () => {
      wsRef.current?.close()
    }
  }, [url])

  const sendMessage = (message: string) => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(message)
    }
  }

  return { sendMessage, lastMessage }
}

