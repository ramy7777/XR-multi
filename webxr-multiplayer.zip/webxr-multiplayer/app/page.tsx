import dynamic from 'next/dynamic'

const WebXRScene = dynamic(() => import('../components/WebXRScene'), { ssr: false })

export default function Home() {
  return <WebXRScene />
}

