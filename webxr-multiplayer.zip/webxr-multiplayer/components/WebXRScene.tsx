'use client'

import { useEffect, useState } from 'react'
import { Canvas } from '@react-three/fiber'
import { VRButton, XR, Controllers, Hands } from '@react-three/xr'
import { useWebSocket } from '../hooks/useWebSocket'
import Player from './Player'

export default function WebXRScene() {
  const [players, setPlayers] = useState<{ id: string; position: [number, number, number] }[]>([])
  const { sendMessage, lastMessage } = useWebSocket('ws://localhost:3001')

  useEffect(() => {
    if (lastMessage) {
      const data = JSON.parse(lastMessage)
      if (data.type === 'playerMove') {
        setPlayers((prevPlayers) => {
          const playerIndex = prevPlayers.findIndex((p) => p.id === data.id)
          if (playerIndex !== -1) {
            const newPlayers = [...prevPlayers]
            newPlayers[playerIndex] = { ...newPlayers[playerIndex], position: data.position }
            return newPlayers
          } else {
            return [...prevPlayers, { id: data.id, position: data.position }]
          }
        })
      }
    }
  }, [lastMessage])

  const handleMove = (position: [number, number, number]) => {
    sendMessage(JSON.stringify({ type: 'playerMove', id: 'localPlayer', position }))
  }

  return (
    <div style={{ width: '100vw', height: '100vh' }}>
      <VRButton />
      <Canvas>
        <XR>
          <ambientLight />
          <pointLight position={[10, 10, 10]} />
          <Controllers />
          <Hands />
          {players.map((player) => (
            <Player key={player.id} position={player.position} />
          ))}
          <Player position={[0, 0, 0]} onMove={handleMove} />
        </XR>
      </Canvas>
    </div>
  )
}

