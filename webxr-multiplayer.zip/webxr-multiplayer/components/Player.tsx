'use client'

import { useRef } from 'react'
import { useFrame } from '@react-three/fiber'
import { useXR } from '@react-three/xr'
import { Mesh } from 'three'

type PlayerProps = {
  position: [number, number, number]
  onMove?: (position: [number, number, number]) => void
}

export default function Player({ position, onMove }: PlayerProps) {
  const meshRef = useRef<Mesh>(null)
  const { player } = useXR()

  useFrame(() => {
    if (meshRef.current && player) {
      meshRef.current.position.copy(player.position)
      if (onMove) {
        onMove([
          player.position.x,
          player.position.y,
          player.position.z
        ])
      }
    }
  })

  return (
    <mesh ref={meshRef} position={position}>
      <boxGeometry args={[0.5, 0.5, 0.5]} />
      <meshStandardMaterial color="blue" />
    </mesh>
  )
}

